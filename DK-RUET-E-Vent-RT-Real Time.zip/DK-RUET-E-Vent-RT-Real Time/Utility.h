/*
 * Utility.h
 *
 * Created: 04-May-20 2:48:32 AM
 *  Author: Rafi
 */ 


#ifndef UTILITY_H_
#define UTILITY_H_

#include "Arduino.h"
//#define DEBUG_PRESSURE_CURRENT
#define RT_UI_COM_MAX_INTERVAL    30  // ms

unsigned long tLoopTimer;                   // Absolute time (s) at start of each control loop iteration
unsigned int tLoopBuffer;  // Amount of time (s) left at end of each loop
ParaMeterValue ParaMeter;

EVentBreath Breath;
HardWareCom ComRT(&Serial3,&ParaMeter);
uint8_t alarmId;
unsigned long RtUiComTime;
bool isBreathEndFlag,isExpEndFlag;

ContinuousInsExpParameter   continuousInsExpParameter;
DebugStateParameter         debugStateParameter;
BreathStateParameter        breathStateParameter;

void sensorBegin(){
  PressureReader.begin();
  Flow.begin();
  pinMode(GAIN0,OUTPUT);
  pinMode(GAIN1,OUTPUT);
  Oxygen.setOffset(-1500);
  Oxygen.power_up();
}

void sendExpEndInfo(){          // float ~ 9 bytes, int ~ 7 bytes, byte ~ 6 bytes total 40 bytes
  ComRT.sendData(DEBUG_STATE_DATA_ID,debugStateParameter);       // 25 bytes
}

void sendBreathEndInfo(){       // float ~ 9 bytes, int ~ 7 bytes, byte ~ 6 bytes total 40 bytes
  //Serial.println(Breath.cycleCount);
  ComRT.sendData(BREATH_STATE_DATA_ID,breathStateParameter);        // 29 bytes
}

bool sendContinuousInfo(){      // float ~ 9 bytes, int ~ 7 bytes total 36 byte
  if(Breath.isInpEnd()){
    debugStateParameter.getSetRpmInsp = Motor.getSetRpm();
    debugStateParameter.reqEncPulseInsp = Breath.reqEncPulse();
    debugStateParameter.actualEncPulseInsp = Breath.actualEncPulse();
    //Serial.println("INSP_END");
  }else if(Breath.isExpEnd()){
    debugStateParameter.getSetRpmExp = Motor.getSetRpm();
    debugStateParameter.reqEncPulseExp = debugStateParameter.actualEncPulseInsp;
    debugStateParameter.actualEncPulseExp = Breath.actualEncPulse();
    debugStateParameter.breathCycleCount = Breath.cycleCount;
    isExpEndFlag = true;
    //Serial.println("EXP_END");
  }else if(Breath.isBreathEnd()){
    breathStateParameter.supplyTidalVol = Breath.actualSupplyTidalVol();
    breathStateParameter.plateau = PressureReader.plateau();
    breathStateParameter.actualBPM = Breath.actualBPM();
    breathStateParameter.peak = PressureReader.peak();
    breathStateParameter.peep = PressureReader.peep();
    breathStateParameter.breathCycleCount = Breath.cycleCount;
    isBreathEndFlag = true;
    //Serial.println("BREATH_END");
  }
  
  if(millis()- RtUiComTime >= RT_UI_COM_MAX_INTERVAL){
    RtUiComTime = millis();
    if(isExpEndFlag){
      sendExpEndInfo();
      isExpEndFlag = false;
      return true;
    }else if(isBreathEndFlag){
      sendBreathEndInfo();
      isBreathEndFlag = false;
      return true;
    }else if(Breath.state == IN_STATE || Breath.state == EX_STATE){ // total 33 bytes
      continuousInsExpParameter.debug.motorCurrent = CurrentSensor.get();
      continuousInsExpParameter.debug.achievedRpm  = Motor.getAchievedRpm();
      continuousInsExpParameter.debug.pidResponse = Motor.pidOutput;
      continuousInsExpParameter.debug.breathCycleCount = Breath.cycleCount;
      continuousInsExpParameter.continuous.flow = Flow.read();
      continuousInsExpParameter.continuous.volume = Flow.volume();
      continuousInsExpParameter.continuous.pressure = PressureReader.get();
      ComRT.sendData(DEBUG_CONTINUOUS_DATA_ID,continuousInsExpParameter);               // 29 bytes 
#ifdef DEBUG_PRESSURE_CURRENT
      Serial.print("P:");
      Serial.println(PressureReader.get());
#endif
    }else{
      continuousInsExpParameter.continuous.flow = Flow.read();
      continuousInsExpParameter.continuous.volume = Flow.volume();
      continuousInsExpParameter.continuous.pressure = PressureReader.get();
      ComRT.sendData(BREATH_CONTINUOUS_DATA_ID,continuousInsExpParameter.continuous);    // float // total 17 bytes
#ifdef DEBUG_PRESSURE_CURRENT
      Serial.print("P:");
      Serial.println(PressureReader.get());
      Serial.print("I:");
      Serial.println(CurrentSensor.get());
#endif
    }
    
    if(Alarm.status()){
        ComRT.sendData(ALARMS_ID,Alarm.get());  // 6 bytes
    }
  }
  return true;
}

int eeAddress = 0;

void setEventParaMeter(){
  ParaMeter.status = 0;       // 0
  ParaMeter.mode = 1;         // 1
  ParaMeter.bpm = 12;         // 2
  ParaMeter.tidalVol = 400;   // 3
  ParaMeter.peep = 5;         // 4
  ParaMeter.fio2 = 50;        // 5
  ParaMeter.preSupport = 20;  // 6
  ParaMeter.i = 1;            // 7
  ParaMeter.e = 2;            // 8
  /*EEPROM.get(eeAddress,paraMeter);
  if(paraMeter.status == 1){
    switch((int)paraMeter.mode){
      case 1:
        //paraMeter.status = 0;
        //SoftSerial.println("Start!");
        Breath.begin(&paraMeter);
      break;
      case 2:
      break;
      case 3:
      break;
      case 4:
      break;
    }
  }*/
}

#endif /* UTILITY_H_ */
