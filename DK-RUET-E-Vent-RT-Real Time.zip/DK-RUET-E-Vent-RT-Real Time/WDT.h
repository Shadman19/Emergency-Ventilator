#ifndef WDT_AD_H
#define WDT_AD_H

#include <Arduino.h>
#include <avr/wdt.h>

//WDTO_15MS   0
//WDTO_30MS   1
//WDTO_60MS   2
//WDTO_120MS  3
//WDTO_250MS  4
//WDTO_500MS  5
//WDTO_1S     6
//WDTO_2S     7
//WDTO_4S     8
//WDTO_8S     9

typedef enum{
  WDT_NONE = 0,
  WDT_INTERRUPT,
  WDT_RESET,
  WDT_INTERRUPT_RESET
}WDT_OPTION;

void wdt_set(WDT_OPTION wdt_option,byte _timer_prescale = WDTO_2S) {
  if(_timer_prescale > WDTO_2S){
    _timer_prescale &= 0xF7; // just clear 4th position according datasheet
    _timer_prescale |= 0x20; // just set 6th position according datasheet
  }
  
  wdt_disable(); //Datasheet recommends disabling WDT right away in case of low probabibliy event
  WDTCSR = (1 << WDCE) | (1 << WDE);
  switch(wdt_option){
    case WDT_NONE:
      WDTCSR = 0x00;
    break;
    case WDT_INTERRUPT:
      WDTCSR = _BV(WDIE) | _timer_prescale;
    break;
    case WDT_RESET:
      WDTCSR = _BV(WDE) | _timer_prescale;
    break;
    case WDT_INTERRUPT_RESET:
      WDTCSR = _BV(WDIE) | _BV(WDE) | _timer_prescale;
    break;
  }
  wdt_reset();
}

#endif
