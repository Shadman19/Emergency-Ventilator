/*
 * Breath.h
 *
 * Created: 02-May-20 1:59:15 PM
 *  Author: Rafi
 */ 


#ifndef BREATH__H_
#define BREATH__H_

#include <Arduino.h>
#include <Define_IO_Pin_RT.h>
#include <Define_Data_Type.h>
#include <BreathAlarm.h>
#include <HoneywellRSC.h>
#include <SFM3200.h>
#include <ADS1232.h>
#include <ACS712.h>
#include <utils.h>

#include "Motor.h"

//#define DEBUG_BREATH_
// Safety settings
#define MAX_PRESSURE              40.0  // Trigger high pressure alarm (cmH2O)
#define MIN_PLATEAU_PRESSURE      5.0   // Trigger low pressure alarm (cmH2O)
#define MAX_RESIST_PRESSURE       2.0   // Trigger high-resistance notification (cmH2O)
#define MIN_TIDAL_PRESSURE        5.0   // Trigger no-tidal-pressure alarm (cmH2O)
#define VOLUME_ERROR_THRESH       50.0  // Trigger incomplete breath alarm (ml)
#define MAX_MOTOR_CURRENT         8.0   // Trigger mechanical failure alarm. Units (A)
#define TURNING_OFF_DURATION      5000  // Turning-off alarm is on for this duration (s)
#define MECHANICAL_TIMEOUT        1000  // Time to wait for the mechanical cycle to finish before alarming
#define MECHANICAL_EXP_TIMEOUT    30    // Time to wait for the mechanical cycle to finish before alarming
#define HOMING_TIMEOUT            1500  // ms
#define INITIAL_INERTIA_TIME      150   // ms

// breath info
#define HOLD_IN_DURATION        100  // Duration (ms) to pause after inhalation
#define MAX_EX_DURATION         1000 // Maximum exhale duration (ms)
#define MIN_PEEP_PAUSE          75   // Time (ms) to pause after exhalation / before watching for an assisted inhalation
#define LOOP_PERIOD             5    // ms

#define FLOW_DATA_ARRAY_LEN   600   // at 10 bpm i:e = 1:1 (max)

class EVentBreath
{
  public:
  EVentBreath();
  void begin(ParaMeterValue *);
  void stop();
  void setState(States);
  void handleErrors();
  bool execute(void);
  bool isInpEnd()				{ return isInpEndSt;                  } // only true at end of insp and before insp_hold
  bool isBreathEnd()			{ return isBreathEndSt;               } // only true at end of breath and before insp
  bool isExpEnd()				{ return isExpEndSt;                  } // only true at end of exp and before peepPause
  float actualSupplyTidalVol()	{ return deliveredTidalVolume;        } // [send]end of breath
  int reqEncPulse()				{ return inspReqTicks;                } // [send]end of breath
  int actualEncPulse()			{ return Motor.getCurrentPulse();     } // [send]end of breath
  float actualBPM()				{ return tPeriodActual<100 ? 0 : 60000.0/(float)tPeriodActual;} // [send]end of breath
  ParaMeterValue *paraMeter;
  States state;
  bool flowError,flowRstType,preError;
  unsigned long cycleCount;
  byte presentPosition;
  
  private:
  void calculateWaveform(float bpm,float i,float e);
  unsigned long expendTime()   { return (millis() - tCycleTimer); }
  void expiration();
  void inspiration();
  void platoState();
  void peepPauseState();
  void peepState();
  void preHomeState();
  void homingState();

  byte flowDataArray[FLOW_DATA_ARRAY_LEN];
  float deliveredTidalVolume,motorCurrent,inertiPWM,genFlowSLM,reservedVolume,rowSLM;
  int inspReqTicks,expReqTicks,flowErrorCount,flowDataLenCount,preErrorCount;
  bool enteringState,patientTriggered,isInpEndSt,isExpEndSt,isBreathEndSt,isStartSt,isReady;
  unsigned long tCycleTimer;     // Absolute time (s) at start of each breathing cycle
  unsigned long tIn;             // Calculated time (s) since tCycleTimer for end of IN_STATE
  unsigned long tHoldIn;         // Calculated time (s) since tCycleTimer for end of HOLD_IN_STATE
  unsigned long tEx;             // Calculated time (s) since tCycleTimer for end of EX_STATE
  unsigned long tPeriod;         // Calculated time (s) since tCycleTimer for end of cycle
  unsigned int tPeriodActual;    // Actual time (s) since tCycleTimer at end of cycle (for logging)
};

#endif /* BREATH__H_ */
