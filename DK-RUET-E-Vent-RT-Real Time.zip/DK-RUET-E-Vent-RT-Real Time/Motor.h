/*
 * Motor.h
 *
 * Created: 02-May-20 4:28:52 PM
 *  Author: Rafi
 */ 


#ifndef MOTOR__H_
#define MOTOR__H_

#include <Arduino.h>
#include <Define_IO_Pin_RT.h>
#include <utils.h>

#define MOTOR_MAX_POS 700
#define DEBOUNCE_TIME_OUT		80 // ms

class MotorClass
{
public:
  MotorClass();
  void init();
  bool stop(void);
  bool end(void);
  bool checkLimit(uint8_t);
  bool isReady(uint8_t _pin);
  bool forword(uint8_t _pwm_percent = 5);
  bool reverse(uint8_t _pwm_percent = 5);
  void limitSwEn();
  void limitSwDis();
  void setFrequency(uint32_t _Frequency_ = 500);
  void setPPR(float = SHAFT_PPR);
  void setPinionDia(float = PINION_DIA);
  void setPid(float _p = 2.50, float _i = 0.50, float _d = 0.50);
  void setRPM(int,int);
  void setRPM(float _rpm)						            { ReqRpm = _rpm;			      }
  void setSLM(float _slm)                       { ReqSLM = _slm;            }
  void setTicks(int _ticks)                     { inspRequardTicks = _ticks;}
  void drive();
  void drive(float);
  float rpmFromEncoder(float _min = 0.0); 
  bool calibrate(uint8_t _pwm_percent = 25,unsigned int timeOut = 5000); // calibrate hardware, return full scale displacement in cm at set initial pos;
  float getAchievedRpm()                        { return motorEncRpm;   } // [send]end at 10 ms of ins and exp
  float getSetRpm()                             { return ReqRpm;        } // [send]end of ins and exp
  float getSetSLM()                             { return ReqSLM;        } // [send]end of ins and exp
  float getCW();
  float getCCW();
  int getCWPulse()                              { return (int)motorPulseCalCW;   }
  int getCCWPulse()                             { return (int)motorPulseCalCCW;  }
  int getCurrentPulse(void);                                              // [send]end of ins and exp
  unsigned int getPulse(unsigned long _timeOut = 5000);
  unsigned int getPulseUntil(char);
  int getPIDmax(void);
  void pwmWrite(float);
  void analogWrite(bool,unsigned int);
  bool status(void)                               { return motorStatus; }
  bool hold();
  void motorEndPos();							                // External Interrupt Service Routine
  void motorEncoder();                            // External Interrupt Service Routine
  void setEncoderInt();
  void clearEncoderInt();
  
  unsigned int motorPulseCalCW,motorPulseCalCCW,pidOutput;
  volatile float IntP,pastVal;
  
private:
  bool calibrating(unsigned int,bool*);
  void motorPID(float,float);
  float pidCorrection(float);
  
  volatile bool motorForEndSt,motorRevEndSt,motorDirection,motorStatus,motorPulseSt,motorLimitStatus;
  volatile unsigned int rackDispInPulse,motorPulse,inspRequardTicks;
  volatile unsigned long motorPulseTime,motorPosDeBounceTimeCheck;
  unsigned int pidMax,pidMin;
  unsigned long motorPulseIncTime;
  float pinionDia,shaftPPR,reqRackDisplacement,ReqRpm,motorEncRpm,Kp,Ki,Kd,ReqSLM;
};

extern MotorClass Motor;

#endif /* MOTOR__H_ */
