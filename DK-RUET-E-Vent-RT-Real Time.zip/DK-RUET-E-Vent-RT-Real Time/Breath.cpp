/*
 * Breath.cpp
 *
 * Created: 22-July-20 12:55:55 AM
 *  Author: Rafi
 */ 

#include "Breath.h"

EVentBreath :: EVentBreath(){
  state = PREHOME_STATE;
  inertiPWM = 5;
  flowErrorCount = 0;
  genFlowSLM = cycleCount = tPeriodActual = motorCurrent = 0;
  isStartSt = isExpEndSt = isInpEndSt = enteringState = false;
  preError = flowError = patientTriggered = isBreathEndSt = false;
}

void EVentBreath :: begin(ParaMeterValue * _val){
  reservedVolume = 0;
  paraMeter = _val;
  presentPosition = 34;/////////////////////////////////////////////////////////////
  calculateWaveform(paraMeter->bpm,paraMeter->i,paraMeter->e);
  //Motor.setTicks(inspReqTicks);
  presentPosition = 35;/////////////////////////////////////////////////////////////
  Motor.init();
  presentPosition = 36;/////////////////////////////////////////////////////////////
  Motor.limitSwEn();
  setState(PREHOME_STATE);
}

void EVentBreath :: setState(States newState) {
  state = newState;
#ifdef DEBUG_BREATH_
  //Serial.println("setState");
#endif
  enteringState = true;
}

void EVentBreath :: calculateWaveform(float bpm,float i,float e) {
  // full breathing cycle time (inhalation,HOLD_IN_DURATION,exhalation,PEEP_PAUSE_STATE,HOLD_EX_STATE) all are included
  tPeriod = (60000.0 / (float)bpm) + 0.5;  // ms in each breathing cycle period
  // inhalation,HOLD_IN_DURATION period are included
  tHoldIn = (((float)tPeriod*i)/(i + e)) + 0.5;
  // inhalation period HOLD_IN_DURATION is not included
  tIn = tHoldIn - HOLD_IN_DURATION;
  // exhalation period (PEEP_PAUSE_STATE,HOLD_EX_STATE) are not included
  tEx = min(tHoldIn + MAX_EX_DURATION, tPeriod - MIN_PEEP_PAUSE);
  tCycleTimer = millis();
  rowSLM = timeVol2FlowRate(paraMeter->tidalVol,(tIn - INITIAL_INERTIA_TIME));
}

bool EVentBreath :: execute(void){
  presentPosition = 2;////////////////////////////////////////////////////////////////

  if(flowError == false){
    if(flowErrorCount >= 5){    // check it for 5 times
      if(flowRstType){
        FlowRST flowRST = Flow.softReset();
        if(flowRST == FLOW_OK){
          flowErrorCount = 0;
        }else if(flowRST == FLOW_FALL){
          flowRstType = false;              // try hardware reset
        }
      }else{
        FlowRST flowRST = Flow.hardReset();
        if(flowRST == FLOW_OK){
          flowErrorCount = 0;
        }else if(flowRST == FLOW_FALL){
          flowError = true;              // sensor/connection may be broken
        }
      }
    }else if(Flow.available()){
      genFlowSLM = Flow.read();
      flowErrorCount = 0;
    }else{
      flowErrorCount++;
      Serial.println("Flow Error Cpp");
      flowRstType = true;
    }
  }
  
  presentPosition = 3;////////////////////////////////////////////////////////////////
  float pre = PressureReader.read();
  if(preError == false){
    if(preErrorCount >= 5){    // check it for 5 times
      RSC_RST rsc_RST = PressureReader.hardReset();
      if(rsc_RST == RSC_OK){
        preErrorCount = 0;
      }else if(rsc_RST == RSC_FALL){
        preError = true;              // sensor/connection may be broken
      }
    }else if(pre < RSC_MIN_L && pre > RSC_MAX_L){ // detect error
      preErrorCount++;
      Serial.println("Pre Error Cpp");
      Serial.println(pre);
    }
  }
  
  presentPosition = 4;////////////////////////////////////////////////////////////////
  motorCurrent = CurrentSensor.read();
  
  presentPosition = 5;////////////////////////////////////////////////////////////////

  Serial.print(genFlowSLM);
  Serial.print(',');
  Serial.println(pre);

  presentPosition = 6;////////////////////////////////////////////////////////////////
	switch (state){
  	case DEBUG_STATE:
    presentPosition = 7;////////////////////////////////////////////////////////////////
  		//stop();
  	break;
    case OFF_STATE:
    presentPosition = 8;////////////////////////////////////////////////////////////////
      stop();
    break;
		case IN_STATE:
    presentPosition = 9;////////////////////////////////////////////////////////////////
		  inspiration();
		break;
    case HOLD_IN_STATE:
    presentPosition = 10;////////////////////////////////////////////////////////////////
      platoState();
    break;
		case EX_STATE:
    presentPosition = 11;////////////////////////////////////////////////////////////////
		  expiration();
		break;
    case PEEP_PAUSE_STATE:
    presentPosition = 12;////////////////////////////////////////////////////////////////
      peepPauseState();
    break;
		case HOLD_EX_STATE:
    presentPosition = 13;////////////////////////////////////////////////////////////////
		  peepState();
		break;
    case PREHOME_STATE:
    presentPosition = 14;////////////////////////////////////////////////////////////////
      preHomeState();
    break;
    case HOMING_STATE:
    presentPosition = 15;////////////////////////////////////////////////////////////////
      homingState();
    break;
	}
	return true;
}

void EVentBreath :: inspiration(){
  if (enteringState) {
#ifdef DEBUG_BREATH_
    Serial.println("inspiration");
#endif
    isReady = isStartSt = true;
    isBreathEndSt = enteringState = false;
    tCycleTimer = millis();   // The cycle begins at the start of inspiration 
    float reqVoulume = paraMeter->tidalVol;//-reservedVolume//      float reqVoulume = paraMeter->tidalVol;//-reservedVolume
    rowSLM = timeVol2FlowRate(reqVoulume,(tIn - INITIAL_INERTIA_TIME));
    Motor.setSLM(rowSLM);
    Serial.print("Flow_");
    Serial.print(rowSLM);
    Serial.print("_slm");
    Serial.print(',');
    Serial.println("Test");
    Motor.forword();
    cycleCount ++;
    flowDataLenCount = 0;
  }
  
  if(flowErrorCount == 0){                                  // valid flow data
    if(flowDataLenCount < FLOW_DATA_ARRAY_LEN){             // verify length
      flowDataArray[flowDataLenCount++] = (byte)genFlowSLM; // store new flow data
    }
  }else{                                                    // invalid flow data
    if(flowDataLenCount < FLOW_DATA_ARRAY_LEN){             // verify length
      genFlowSLM = (float)flowDataArray[flowDataLenCount++];// use past flow data
    }else{
      Motor.stop();
      genFlowSLM = 0;
    }
  }

  if(Motor.status()){
    Motor.drive(genFlowSLM);
  }

  if(Flow.volume() >= paraMeter->tidalVol){ // volume or time out has same effect
    isInpEndSt = true;
#ifdef DEBUG_BREATH_
    Serial.println("volume achieved");
#endif
    Motor.stop();
    setState(HOLD_IN_STATE);
  }else if(expendTime() > tIn){
    isInpEndSt = true;
#ifdef DEBUG_BREATH_
    Serial.println("time out");
#endif
    Motor.stop();
    setState(HOLD_IN_STATE);
  }
}
void EVentBreath :: platoState(){
  if (enteringState) {
    isInpEndSt = false;
#ifdef DEBUG_BREATH_
    Serial.println("platoState");
#endif
    enteringState = false;
  }
  
  //Flow.volumeReset();
  if (expendTime() > tHoldIn) {
    PressureReader.set_plateau();
    setState(EX_STATE);
  }
}

void EVentBreath :: expiration(){
  if (enteringState){
    Serial.print("Vol_");
    Serial.print(Flow.volume());
    Serial.print("_ml");
    Serial.print(',');
    Serial.println("Test");
#ifdef DEBUG_BREATH_
    Serial.println("expiration");
#endif
    enteringState = false;
	  expReqTicks = Motor.getCurrentPulse()+75;
    Motor.setRPM(expReqTicks,int(tEx - expendTime()));
    Motor.reverse();
  }
  if (Motor.status()) {
	  Motor.drive();
  }
  
  //Flow.volumeReset();
  if (Motor.status() == false) { // motor may be reached to the homing position
    isExpEndSt = true;
    setState(PEEP_PAUSE_STATE);
  }else if(expendTime() > (tEx + MECHANICAL_EXP_TIMEOUT)){// motor take too much time to reach or it may be stucked
    isExpEndSt = true;
    Motor.stop();
    setState(PEEP_PAUSE_STATE);
  }
}

void EVentBreath :: peepPauseState(){
  if (enteringState) {
#ifdef DEBUG_BREATH_
    Serial.println("peepPauseState");
#endif
    isExpEndSt = enteringState = false;
  }
  
  //Flow.volumeReset();
  if (expendTime() > (tEx + MIN_PEEP_PAUSE)) {
    PressureReader.set_peep();
    Serial.print("PEEP:");
    Serial.println(PressureReader.peep());
    setState(HOLD_EX_STATE);
  }
}

void EVentBreath :: peepState(){
  if (enteringState) {
#ifdef DEBUG_BREATH_
    Serial.println("peepState");
#endif
    enteringState = false;
  }
  
  //Flow.volumeReset();
  patientTriggered = PressureReader.get() < (PressureReader.peep() - paraMeter->peep);  // Check if patient triggers inhale

  if (patientTriggered || (expendTime() > tPeriod)) {
    if (!patientTriggered) PressureReader.set_peep();  // Set peep again if time triggered
    PressureReader.set_peak_and_reset();
	  tPeriodActual = (unsigned int)(millis() - tCycleTimer);
    reservedVolume = Flow.volume();
    Flow.volumeReset();
    isBreathEndSt = true;
#ifdef DEBUG_BREATH_
    Serial.println("Breath End");
#endif
    setState(IN_STATE);
  }
}

void EVentBreath :: preHomeState(){// calling when breath 1st time starts and also for stop
  if (enteringState) {
    enteringState = false;
    if(!Motor.status()){
      setState(HOMING_STATE);
    }
    Motor.stop();
    tCycleTimer = millis();
#ifdef DEBUG_BREATH_
    Serial.println("preHomeState");
#endif
  }

  if(expendTime() > 500UL){ // 200 ms
    setState(HOMING_STATE);
  }
}

void EVentBreath :: homingState(){ // calling when breath 1st time starts this actually starts the breath
  if (enteringState){
    if(Motor.status()){
      if(expendTime() > HOMING_TIMEOUT){ // Motor.reverse(40); may executing
        Motor.stop();
        tCycleTimer = millis();
#ifdef DEBUG_BREATH_
        Serial.println("homingState");
#endif
        enteringState = false;
      }
    }else if(!Motor.checkLimit(RACK_OPEN_LIMIT1)){      // rack at not Homing State and not stuck at end
      Motor.reverse(40);                                // returns home at 40% speed
      tCycleTimer = millis();
    }else{                                              // rack at Homing State
#ifdef DEBUG_BREATH_
      Serial.println("homingState");
#endif
      enteringState = false;
      tCycleTimer = millis();
    }
  }else{
    if (paraMeter->status == 0x01){
      if(expendTime() > 200UL){
#ifdef DEBUG_BREATH_
        Serial.println("Start breath!");
#endif
        Flow.volumeReset();
        setState(IN_STATE);
      }
    }else if(Motor.status()){
      setState(PREHOME_STATE);
    }else{
      setState(DEBUG_STATE);
    }
  }
}

void EVentBreath :: stop(){
  cycleCount = 0;
  isStartSt = false;
  paraMeter->status = 0x00;
  setState(PREHOME_STATE);
}

void EVentBreath :: handleErrors() {
  // Pressure alarms
  const bool over_pressure = PressureReader.get() >= MAX_PRESSURE;
  Alarm.handler(HIGH_PRESSURE_ID,over_pressure);
  if (over_pressure) setState(PREHOME_STATE);  // doing everything for us

  // These pressure alarms only make sense after homing 
  if (enteringState && state == IN_STATE) {              // only execute after exhelation and before inhelation
    if(isStartSt){
      Alarm.handler(BAD_PLATEAU_ID,(PressureReader.peak() - PressureReader.plateau()) > MAX_RESIST_PRESSURE);
      Alarm.handler(TUBE_LEAK_ID,PressureReader.plateau() < MIN_PLATEAU_PRESSURE);
      Alarm.handler(NO_TIDAL_PRESSURE_ID,(PressureReader.peak() - PressureReader.peep()) < MIN_TIDAL_PRESSURE);
    }
  }

  // Check if desired volume was reached
  if (enteringState && state == EX_STATE) {         // only execute after inhelation and before next state
    deliveredTidalVolume = Flow.volume();           // achieved volume after ins
    Alarm.handler(UNMET_VOLUME_ID,(paraMeter->tidalVol - deliveredTidalVolume) > VOLUME_ERROR_THRESH);
  }

  // Check if maximum motor current was exceeded
  if(state == EX_STATE || state == IN_STATE){
    if (motorCurrent >= MAX_MOTOR_CURRENT) {
      setState(EX_STATE);
      Alarm.handler(OVER_CURRENT_ID,true);
    }else{
      Alarm.handler(OVER_CURRENT_ID,false);
    }
  }

  // Check if we've gotten stuck in EX_STATE (mechanical cycle didn't finsih)
  Alarm.handler(MECHANICAL_FAILURE_ID,((state == EX_STATE) && (expendTime() > (tPeriod + MECHANICAL_TIMEOUT))));
}
