/*
 * Motor.cpp
 *
 * Created: 02-May-20 4:28:52 PM
 *  Author: Rafi
 */
#include "Motor.h"

MotorClass :: MotorClass(){
	motorLimitStatus = false;
	pinMode(MOTOR_EN,OUTPUT);
	digitalWrite(MOTOR_EN,LOW);
}

void MotorClass :: init(){
	inspRequardTicks = 30000;
	end();
	setPPR();
	setPinionDia();
	pinMode(M_PWM_CW_PIN,OUTPUT);
	pinMode(M_PWM_CCW_PIN,OUTPUT);
	setEncoderInt();
	setFrequency();
	setPid();
}

void MotorClass :: setEncoderInt(){
	EICRB |= _BV(ISC50)|_BV(ISC51);				// Interrupt Mode -> The rising edge
	EIMSK |= _BV(INT5);							// External Interrupt Enable 5
	EIFR |= _BV(INTF5);							// flag can be cleared by writing a logical one to it
	//sei();
}

void MotorClass :: clearEncoderInt(){
	EICRB &= ~(_BV(ISC50)|_BV(ISC51));			// Interrupt Mode -> The rising edge
	EIMSK &= ~_BV(INT5);						// External Interrupt Enable 5
}

void MotorClass :: setRPM(int _encPulse,int _timeMs){
	ReqRpm = rpmFromDisplacementAndTime(encoderToDisplacement((float)_encPulse,pinionDia,shaftPPR),_timeMs);
}

bool MotorClass :: hold(){
	stop();
	digitalWrite(M_PWM_CW_PIN,HIGH);
	digitalWrite(M_PWM_CCW_PIN,HIGH);
}

void MotorClass :: setPPR(float _ppr){
	shaftPPR = _ppr;
}

void MotorClass :: setPinionDia(float p_dia){
	pinionDia = p_dia;
}

unsigned int MotorClass :: getPulse(unsigned long _timeOut){
	rackDispInPulse = 0;
	unsigned long _time = millis();
	while(millis() - _time < _timeOut);
	return rackDispInPulse;
}

unsigned int MotorClass :: getPulseUntil(char _ch){
	rackDispInPulse = 0;
	while(1){
		if (Serial.available()){
			if (Serial.read() == _ch){
				while(Serial.available()){ Serial.read() ;}
				break;
			}
		}
	}
	return rackDispInPulse;
}

int MotorClass :: getPIDmax(void){
	return pidMax;
}

int MotorClass :: getCurrentPulse(void){
	return (int)rackDispInPulse;
}

float MotorClass :: getCW(){
	return encoderToDisplacement(motorPulseCalCW,pinionDia,shaftPPR);
}

float MotorClass :: getCCW(){
	return encoderToDisplacement(motorPulseCalCCW,pinionDia,shaftPPR);
}

void MotorClass :: motorEncoder(){
	if (!motorPulseSt){
		motorPulseTime = micros();
		motorForEndSt = motorRevEndSt = false;					// moved
		motorPulseSt = true;
	}
	motorPulse ++;
	rackDispInPulse ++;
	motorPulseTime = micros() - motorPulseTime;
	motorPulseIncTime += motorPulseTime;						// in ms
	motorPulseTime = micros();
	if(motorDirection){
		if(rackDispInPulse > MOTOR_MAX_POS){						// additional safety for volume that may not exceed
		  stop();
		}
	}
}

void MotorClass :: drive(){
	motorPID(ReqRpm,rpmFromEncoder(ReqRpm));
}

void MotorClass :: drive(float _gen_slm){
 motorPID(ReqSLM,_gen_slm);
}

void MotorClass :: motorPID(float _rpmInsExp,float _motorRpm){
	float _error = _rpmInsExp - _motorRpm;
	IntP += (Ki*_error);										// Calculating I term
	IntP = pidCorrection(IntP);
	int dInput = _motorRpm - pastVal;							// Calculating D term
	float Output =  Kp*_error + IntP ;							// Calculating P term
	Output -= Kd*(float)dInput;									// Compute PID Output
	Output = pidCorrection(Output);
	pastVal = _motorRpm;
	pidOutput = (unsigned int)Output;
	analogWrite(motorDirection,pidOutput);
}

float MotorClass :: rpmFromEncoder(float _min){
	if (motorPulseIncTime < 500){								// this function executed every 3ms
		_min *= 0.1;
		_min = -_min;
		motorPulse = 0;
		//motorEncRpm = _min;
		//return _min;
		motorEncRpm = _min;
		return 0;
	}
	double _enTime = motorPulseIncTime*0.001;     // ms
	double _motorRpm = motorPulse*60000.0;
	_motorRpm /= double(shaftPPR)*_enTime;
	motorPulseIncTime = motorPulse = 0;
	motorEncRpm = _motorRpm;
	return _motorRpm;
}

void MotorClass :: setFrequency(uint32_t _Frequency){
	digitalWrite(MOTOR_EN,HIGH);
	TCCR1A = _BV(WGM11);
	TCCR1B = _BV(WGM12)|_BV(WGM13)|_BV(CS11)|_BV(CS10);			// clkI/O/64 (From prescaler)
	ICR1 = (uint16_t)((F_CPU/_Frequency/64.0) - 0.5) ;
	pidMax = ICR1;
	pidMin = (pidMax*0.02)+0.5 ;								// 2% of max
}

void MotorClass :: setPid(float _p, float _i, float _d){
	Kp = _p, Ki = _i, Kd = _d;
}

bool MotorClass :: forword(uint8_t _pwm_percent){				// M_PWM_CW_PIN in active mode
	stop();
	if (motorLimitStatus){
		if (isReady(RACK_CLOSE_LIMIT1)){			    // already at end position (pressed) now go to start (unpressed) or reverse
			return false;
		}else if (isReady(RACK_OPEN_LIMIT1)){			// already at start position (unpressed) now go to end (pressed) or forword
			motorPosDeBounceTimeCheck = millis();				// de-bounce may occur, this actually prevent de-bounce when this limit switch released.
		}
	}
	rackDispInPulse = motorPulse = 0;
	motorStatus = motorDirection = true;
	TCCR1A |= _BV(COM1C1);
	pwmWrite(_pwm_percent);
	return true;
}

bool MotorClass :: reverse(uint8_t _pwm_percent){				// M_PWM_CCW_PIN in active mode
	stop();
	if (motorLimitStatus){
		if (isReady(RACK_OPEN_LIMIT1)){			    // already at start position (unpressed) now go to end (pressed) or forword
			return false;
		}else if (isReady(RACK_CLOSE_LIMIT1)){			// already at end position (pressed) now go to start (unpressed) or reverse
			motorPosDeBounceTimeCheck = millis();				// de-bounce may occur, this actually prevent de-bounce when this limit switch released.
		}
	}
	rackDispInPulse = motorPulse = 0;
	motorStatus = true;
	motorDirection = false;
	TCCR1A |= _BV(COM1A1);
	pwmWrite(_pwm_percent);
	return true;
}

void MotorClass :: pwmWrite(float _pwmPercent){
	float _val = (pidMax*_pwmPercent)*0.01;
	analogWrite(motorDirection,int(_val+0.5));
}

void MotorClass :: analogWrite(bool _direction,unsigned int _pwmValu){
	_direction ? OCR1C = _pwmValu : OCR1A = _pwmValu; 
}

bool MotorClass :: stop(void){
	TCCR1A &= ~(_BV(COM1C0)|_BV(COM1C1)|_BV(COM1A0)|_BV(COM1A1));		// both PWM channel are released
	digitalWrite(M_PWM_CW_PIN,LOW);
	digitalWrite(M_PWM_CCW_PIN,LOW);
	motorStatus = motorPulseSt = false;
	pastVal = IntP = 0;
	return false;
}

bool MotorClass :: end(void){
	stop();
	OCR1A = OCR1B = TCCR1A = TCCR1B = 0x00;								// clear PWM
	digitalWrite(MOTOR_EN,LOW);
	pinMode(M_PWM_CW_PIN,INPUT);
	pinMode(M_PWM_CCW_PIN,INPUT);
	return false;
}

float MotorClass :: pidCorrection(float _value){
	if(_value > pidMax)         _value = (float)pidMax;
	else if(_value < pidMin)    _value = (float)pidMin;
	return _value;
}

void MotorClass :: limitSwEn(){
	motorLimitStatus = true;
	DDRK &= ~(_BV(RACK_OPEN_LIMIT1)|_BV(RACK_CLOSE_LIMIT1)|_BV(RACK_OPEN_LIMIT2)|_BV(RACK_CLOSE_LIMIT2)); // set as input
	PCICR |= _BV(PCIE2);												// en int for pcint 16:23 // PORTD
	PCMSK2 = _BV(RACK_CLOSE_LIMIT1)|_BV(RACK_OPEN_LIMIT1);		// en int for RACK_OPEN_LIMIT1,RACK_CLOSE_LIMIT1 pins
}

void MotorClass :: limitSwDis(){
	PCICR &= ~_BV(PCIE2);												// dis int for pcint 16:23 // PORTD
	PCMSK2 &= ~(_BV(RACK_CLOSE_LIMIT1)|_BV(RACK_OPEN_LIMIT1));	// dis int for RACK_OPEN_LIMIT1,RACK_CLOSE_LIMIT1 pins
	motorLimitStatus = motorForEndSt = motorRevEndSt = false;
}

void MotorClass :: motorEndPos(){
	//Serial.println("Int T");
	if (motorLimitStatus){
		if ((millis() - motorPosDeBounceTimeCheck) > DEBOUNCE_TIME_OUT){
			if (checkLimit(RACK_CLOSE_LIMIT1)){		// reaches at end point (Start -> End)=(unpressed -> pressed)
				//Serial.println("Int OPEN");
				stop();
				motorForEndSt = true;
			}else if (checkLimit(RACK_OPEN_LIMIT1)){	// reaches at start point (End -> Start)=(pressed -> unpressed)
				//Serial.println("Int CLOSE");
				stop();
				motorRevEndSt = true;
			}else{
				motorForEndSt = motorRevEndSt = false;
			}
			motorPosDeBounceTimeCheck = millis();
		}
	}
}

bool MotorClass :: isReady(uint8_t _pin){ // verify 5 times, true is priority result need 50us
  byte _count = 0;
  for (byte i = 0;i<5;i++){
    bool _st = bool(PINK & _BV(_pin));
    delayMicroseconds(8);
    _count += (byte)_st;
  }
  //Serial.println(_count);
  return (_count > 2) ? true : false;
}

bool MotorClass :: checkLimit(uint8_t _pin){ // verify 3 times, true is priority result
	bool _st = bool(PINK & _BV(_pin));
	_st |= bool(PINK & _BV(_pin));
	_st |= bool(PINK & _BV(_pin));
	return _st;
}

bool MotorClass :: calibrate(uint8_t _pwm_percent,unsigned int timeOut){
  motorPulseCalCW = motorPulseCalCCW = 0;
  if (checkLimit(RACK_OPEN_LIMIT1) && checkLimit(RACK_CLOSE_LIMIT1)){
    stop();									// device may faulty
    return false;							// terminate
  }
  
  if (checkLimit(RACK_OPEN_LIMIT1)){  // already at start (unpressed) position now go to end (pressed)
    forword(_pwm_percent);					// try to go ahead
  }else{									// stay at middle position
    reverse(_pwm_percent);					// try to go back
  }
											// enable limit switch function
  motorForEndSt = motorRevEndSt = false;
  if (calibrating(timeOut,&(motorDirection ? motorForEndSt : motorRevEndSt))){  // motor in move
    return false;
  }
  delay(150);
  if (motorDirection){
    motorPulseCalCW = rackDispInPulse;
  }else{
    forword(_pwm_percent);							// try to go ahead
    motorForEndSt = false;
    if (calibrating(timeOut,&motorForEndSt)){		// motor in move
      return false;
    }
    motorPulseCalCW = rackDispInPulse;
  }
  delay(150);
  reverse(_pwm_percent);
  motorRevEndSt = false;
  if (calibrating(timeOut,&motorRevEndSt)){			// motor in move
    return false;
  }
  motorPulseCalCCW = rackDispInPulse;
  return true;
}

bool MotorClass :: calibrating(unsigned int timeOut,bool *_st){
  unsigned long stTime = millis();
  bool st = *_st;
  while(!st){
    if (millis() - stTime > timeOut){
      stop();										// device may faulty
      return true;									// terminate
    }
    st = *_st;
  }
  return false;
}

ISR(INT5_vect){										// External Interrupt Service Routine
	Motor.motorEncoder();
}

ISR(PCINT2_vect){
	Motor.motorEndPos();
}

// Preinstantiate Objects //////////////////////////////////////////////////////

MotorClass Motor = MotorClass();
